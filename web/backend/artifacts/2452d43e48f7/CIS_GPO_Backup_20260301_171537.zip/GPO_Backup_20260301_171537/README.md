﻿# CIS Windows Hardening GPO Backup

Generated: 2026-03-01 17:15:38
GPO Name: CIS_Hardening_20260301_171537
Rules Included: 4

## Quick Start

### Option 1: Use the Import Script (Recommended)
```powershell
# Run as Domain Admin on a Domain Controller or RSAT-enabled machine
.\Import-Policy.ps1
```

### Option 2: Using Group Policy Management Console (GPMC)
1. Open Group Policy Management Console
2. Right-click on "Group Policy Objects"
3. Select "Import Settings..."
4. Browse to this folder
5. Select the backup to import

### Option 3: Manual PowerShell
```powershell
Import-Module GroupPolicy
Import-GPO -BackupId "{F2E73750-2E57-4D25-80E5-AC22F462FA28}" -Path "<path-to-this-folder>" -TargetName "CIS_Hardening_20260301_171537" -CreateIfNeeded
```

## Rules Included

- CIS 18.6.10.2: Ensure 'Turn off Microsoft Peer-to-Peer Networking Services' is set to 'Enabled'
- CIS 18.6.11.2: Ensure 'Prohibit installation and configuration of Network Bridge' is set to 'Enabled'
- CIS 18.6.11.3: Ensure 'Prohibit use of Internet Connection Sharing' is set to 'Enabled'
- CIS 18.6.14.1: Ensure 'Hardened UNC Paths' is set to 'Enabled' for NETLOGON and SYSVOL


## Important Notes

- **Review before deployment** â€” Always verify settings in GPMC before linking
- **Test first** â€” Apply to a test OU with a few machines before organization-wide rollout
- **Not linked by default** â€” The imported GPO must be manually linked to target OUs
- **Portable** â€” Domain metadata in XML files are generic placeholders; Import-GPO handles remapping automatically
