﻿#Requires -RunAsAdministrator
#Requires -Modules GroupPolicy
<#
.SYNOPSIS
    Imports the CIS Hardening GPO backup into your Active Directory environment.

.DESCRIPTION
    This script imports the pre-configured CIS Benchmark hardening policy
    into your domain as a new Group Policy Object.

    Generated: 2026-02-26T13:22:44
    GPO Name:  CIS_Hardening_20260226_132242
    Rules:     4
#   - CIS 1.1.1: Ensure 'Enforce password history' is set to '24 or more password(s)'
#   - CIS 1.1.2: Ensure 'Maximum password age' is set to '365 or fewer days, but not 0'
#   - CIS 1.1.3: Ensure 'Minimum password age' is set to '1 or more day(s)'
#   - CIS 1.1.4: Ensure 'Minimum password length' is set to '14 or more character(s)'

.PARAMETER TargetName
    Name for the imported GPO. Defaults to 'CIS_Hardening_20260226_132242'.

.PARAMETER Force
    Skip the confirmation prompt.

.EXAMPLE
    .\Import-Policy.ps1
    # Imports with default name, prompts for confirmation

.EXAMPLE
    .\Import-Policy.ps1 -TargetName "Production CIS Policy" -Force
    # Imports with custom name, no confirmation

.NOTES
    - Must be run on a Domain Controller or a machine with RSAT-GroupPolicy installed
    - Requires Domain Admin or equivalent GPO management permissions
    - The imported GPO is NOT linked to any OU by default - link it manually after review
#>
[CmdletBinding()]
param(
    [Parameter()]
    [string]$TargetName = "CIS_Hardening_20260226_132242",

    [Parameter()]
    [switch]$Force
)

$ErrorActionPreference = "Stop"

# -- Pre-flight checks ---------------------------------------------
try {
    Import-Module GroupPolicy -ErrorAction Stop
} catch {
    Write-Error "GroupPolicy module not found. Install RSAT or run this on a Domain Controller."
    exit 1
}

# Resolve paths relative to this script's location
$backupPath = $PSScriptRoot
$backupId   = "{99B88D94-C3E3-48C4-A81C-8D8A13584E41}"

# -- Confirmation --------------------------------------------------
Write-Host ""
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "     CIS Hardening GPO Import Utility                           " -ForegroundColor Cyan
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Backup Path : $backupPath"  -ForegroundColor Gray
Write-Host "  Backup ID   : $backupId"    -ForegroundColor Gray
Write-Host "  Target GPO  : $TargetName"  -ForegroundColor White
Write-Host "  Rules Count : 4"          -ForegroundColor Gray
Write-Host ""

if (-not $Force) {
    $confirm = Read-Host "Import this GPO into your domain? (Y/N)"
    if ($confirm -notin @('Y', 'y', 'Yes', 'yes')) {
        Write-Host "Import cancelled." -ForegroundColor Yellow
        exit 0
    }
}

# -- Import --------------------------------------------------------
Write-Host ""
Write-Host "[*] Importing GPO backup..." -ForegroundColor Cyan

try {
    $result = Import-GPO `
        -BackupId $backupId `
        -Path $backupPath `
        -TargetName $TargetName `
        -CreateIfNeeded

    Write-Host ""
    Write-Host "[+] GPO imported successfully!" -ForegroundColor Green
    Write-Host ""
    Write-Host "  GPO Name    : $($result.DisplayName)" -ForegroundColor White
    Write-Host "  GPO ID      : $($result.Id)"          -ForegroundColor Gray
    Write-Host "  Domain      : $($result.DomainName)"  -ForegroundColor Gray
    Write-Host ""
    Write-Host "[!] IMPORTANT: The GPO is NOT linked to any OU yet." -ForegroundColor Yellow
    Write-Host "    Review the settings in GPMC, then link it to the appropriate OU." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "    Example to link via PowerShell:" -ForegroundColor Gray
    Write-Host "    New-GPLink -Name '$TargetName' -Target 'OU=Workstations,DC=yourdomain,DC=com'" -ForegroundColor DarkGray
    Write-Host ""
} catch {
    Write-Host ""
    Write-Host "[X] Import failed: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    Write-Host "    Common causes:" -ForegroundColor Yellow
    Write-Host "    - Not running as Domain Admin" -ForegroundColor Gray
    Write-Host "    - GroupPolicy module not available" -ForegroundColor Gray
    Write-Host "    - Backup folder structure is incomplete" -ForegroundColor Gray
    exit 1
}
